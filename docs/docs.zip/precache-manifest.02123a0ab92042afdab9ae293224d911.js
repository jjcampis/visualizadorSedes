self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c0b4dd3a420982093b7f",
    "url": "/dashboard/2/css/app.648301d6.css"
  },
  {
    "revision": "4cef9e7f18a649cdba2a",
    "url": "/dashboard/2/css/chunk-vendors.f16c61a5.css"
  },
  {
    "revision": "c32d86285d87a0a73294",
    "url": "/dashboard/2/css/imprimir.4a6abb78.css"
  },
  {
    "revision": "594e0a08469d93230bfc",
    "url": "/dashboard/2/css/rubG.44386c9e.css"
  },
  {
    "revision": "cde915d56a689f43adc0",
    "url": "/dashboard/2/css/rubricaT.44386c9e.css"
  },
  {
    "revision": "e980145be03383d7c6e6",
    "url": "/dashboard/2/css/rubrigaG.44386c9e.css"
  },
  {
    "revision": "9cacdc876e2049988fcab540c21738d5",
    "url": "/dashboard/2/fonts/materialdesignicons-webfont.9cacdc87.eot"
  },
  {
    "revision": "9d243c168a4f1c2cb3cec74884344de7",
    "url": "/dashboard/2/fonts/materialdesignicons-webfont.9d243c16.woff2"
  },
  {
    "revision": "a0711490bcd581b647329230b3e915cf",
    "url": "/dashboard/2/fonts/materialdesignicons-webfont.a0711490.woff"
  },
  {
    "revision": "b62641afc9ab487008e996a5c5865e56",
    "url": "/dashboard/2/fonts/materialdesignicons-webfont.b62641af.ttf"
  },
  {
    "revision": "71baec0f7ef12de464e8b586a0d0364a",
    "url": "/dashboard/2/img/dash.71baec0f.png"
  },
  {
    "revision": "f737fb94f7411ed0600d87b5d8cd1054",
    "url": "/dashboard/2/img/logo_red_maker.f737fb94.png"
  },
  {
    "revision": "94c948817a346c8d3c778d84fb4ecff9",
    "url": "/dashboard/2/index.html"
  },
  {
    "revision": "289b79b1ef799f016107",
    "url": "/dashboard/2/js/about.b5151dfe.js"
  },
  {
    "revision": "c0b4dd3a420982093b7f",
    "url": "/dashboard/2/js/app.2da70c03.js"
  },
  {
    "revision": "4cef9e7f18a649cdba2a",
    "url": "/dashboard/2/js/chunk-vendors.55a89e97.js"
  },
  {
    "revision": "c32d86285d87a0a73294",
    "url": "/dashboard/2/js/imprimir.35eafbad.js"
  },
  {
    "revision": "0728000ab94362a648cd",
    "url": "/dashboard/2/js/newhome.043c062c.js"
  },
  {
    "revision": "594e0a08469d93230bfc",
    "url": "/dashboard/2/js/rubG.0c152a9d.js"
  },
  {
    "revision": "cde915d56a689f43adc0",
    "url": "/dashboard/2/js/rubricaT.5952805a.js"
  },
  {
    "revision": "e980145be03383d7c6e6",
    "url": "/dashboard/2/js/rubrigaG.a7e73db3.js"
  },
  {
    "revision": "43bba3415fe968a61880",
    "url": "/dashboard/2/js/test.4c147732.js"
  },
  {
    "revision": "2889e5b49f3a4f58006518df355b2f7f",
    "url": "/dashboard/2/json.html"
  },
  {
    "revision": "f771bf19a206a40a6ef02bdc8eb3b263",
    "url": "/dashboard/2/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/dashboard/2/robots.txt"
  }
]);